import index from "./pages";

const router = () => {
  return <>
  </path> : "/"
  </Element> : "create"
  </>;
};

export default router;
