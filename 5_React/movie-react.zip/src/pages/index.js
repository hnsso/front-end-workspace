import router from "../router";

const index = () => {
  return;
};

export default index;
