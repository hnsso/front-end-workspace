import axios from "axios";

const Layout = () => {
  return <></>;
};

export default Layout;
